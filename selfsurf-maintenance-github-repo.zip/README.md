# SelfSurf maintenance workflow

This is a small, independent GitHub Actions repository for checking the existing
SelfSurf Supabase graph. It does not contain or change the Netlify Drop website.

## What it does
- Runs at 08:00 UTC on calendar dates 1, 7, 13, 19, 25, 28 and 30.
- Can also be started manually from GitHub Actions.
- Makes one read-only REST request to `ss_blocks`.
- Does not insert, update or delete graph data.

## Install
1. Create a new GitHub repository, preferably private, named `selfsurf-maintenance`.
2. Extract this ZIP archive on your computer.
3. In the new repository, choose **Add file → Upload files**.
4. Upload the `.github` folder and `README.md`, preserving the folder structure.
5. Commit the files to the default branch.
6. Open **Actions** → **SelfSurf Silent Maintenance** → **Run workflow**.

No GitHub secrets are required.

## Limitations
- These are calendar dates, not a strict repeating six-day interval.
- GitHub scheduled runs can be delayed.
- A successful read does not guarantee Supabase will avoid inactivity pausing.
- The publishable key cannot unpause or restore a paused Supabase project.
- The check works only if Supabase's existing API/RLS policies allow this read.
